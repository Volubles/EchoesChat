package com.voluble.echoeschat.commands;

import com.voluble.echoeschat.managers.EmoteColorManager;
import com.voluble.echoeschat.managers.EmoteColorManager.EmoteColorConfig;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;

public class ChatCommand implements CommandExecutor {
	private final JavaPlugin plugin;
	private final EmoteColorManager emoteColorManager;
	private final Map<UUID, String> playerEmoteColors;

	public ChatCommand(JavaPlugin plugin, EmoteColorManager emoteColorManager, Map<UUID, String> playerEmoteColors) {
		this.plugin = plugin;
		this.emoteColorManager = emoteColorManager;
		this.playerEmoteColors = playerEmoteColors;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if (!(sender instanceof Player)) {
			sender.sendMessage(ChatColor.RED + "Only players can use this command.");
			return false;
		}

		Player player = (Player) sender;
		UUID playerUUID = player.getUniqueId();

		if (args.length == 0 || (args.length == 1 && args[0].equalsIgnoreCase("emotecolor"))) {
			player.sendMessage(getAvailableColorsMessage(player));
			return true;
		}

		if (args.length == 1) {
			// Set the player's emote color
			String colorName = args[0].toLowerCase();
			EmoteColorConfig colorConfig = emoteColorManager.getEmoteColor(colorName);

			if (colorConfig == null) {
				player.sendMessage(ChatColor.RED + "Invalid emote color. Use /chat emotecolor to see available options.");
				return false;
			}

			if (!player.hasPermission(colorConfig.getPermission())) {
				player.sendMessage(ChatColor.RED + colorConfig.getDeniedMessage());
				return false;
			}

			playerEmoteColors.put(playerUUID, colorName);
			player.sendMessage(ChatColor.GREEN + "Your emote color has been set to " + ChatColor.translateAlternateColorCodes('&', colorConfig.getColor()) + colorName + ChatColor.RESET + "!");
			return true;
		}

		player.sendMessage(ChatColor.RED + "Usage: /chat emotecolor [<color>]");
		return false;
	}

	/**
	 * Generates a message listing all available emote colors for the player.
	 *
	 * @param player The player requesting the list.
	 * @return A formatted string showing all available colors.
	 */
	private String getAvailableColorsMessage(Player player) {
		StringBuilder message = new StringBuilder(ChatColor.GOLD + "Available Emote Colors: " + ChatColor.RESET);

		for (Map.Entry<String, EmoteColorConfig> entry : emoteColorManager.getAllColors().entrySet()) {
			String colorName = entry.getKey();
			EmoteColorConfig colorConfig = entry.getValue();
			String colorCode = colorConfig.getColor();

			if (colorCode == null || colorName == null) continue; // Skip invalid configurations

			if (player.hasPermission(colorConfig.getPermission())) {
				message.append(ChatColor.translateAlternateColorCodes('&', colorCode))
						.append(colorName)
						.append(ChatColor.RESET)
						.append(", ");
			}
		}

		// Remove the trailing comma and space
		if (message.length() > 2) {
			message.setLength(message.length() - 2);
		}

		return message.toString();
	}

}
