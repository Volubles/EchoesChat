package com.voluble.echoeschat.managers;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.Map;

public class EmoteColorManager {

	private final Map<String, EmoteColorConfig> emoteColors = new HashMap<>();
	private static final String DEFAULT_COLOR_NAME = "default";

	public EmoteColorManager(FileConfiguration config) {
		loadEmoteColors(config);
	}

	/**
	 * Loads emote colors from the config file into memory.
	 *
	 * @param config The configuration file to load emote colors from.
	 */
	private void loadEmoteColors(FileConfiguration config) {
		if (config.contains("emoteColors")) {
			for (String key : config.getConfigurationSection("emoteColors").getKeys(false)) {
				String color = config.getString("emoteColors." + key + ".color");
				String permission = config.getString("emoteColors." + key + ".permission", "");
				String deniedMessage = config.getString("emoteColors." + key + ".deniedMessage", "");

				if (isValidColor(color)) {
					emoteColors.put(key.toLowerCase(), new EmoteColorConfig(color, permission, deniedMessage));
				} else {
					System.out.println(ChatColor.RED + "Invalid emote color configuration: " + key + " with color: " + color);
				}
			}
		}

		// Ensure a default color is always defined
		if (!emoteColors.containsKey(DEFAULT_COLOR_NAME)) {
			emoteColors.put(DEFAULT_COLOR_NAME, new EmoteColorConfig("#FFFFFF", "", "You cannot use this color."));
			System.out.println(ChatColor.YELLOW + "Default emote color set to white (#FFFFFF).");
		}
	}

	/**
	 * Validates if a color string is a valid hex or standard Minecraft color code.
	 *
	 * @param color The color string to validate.
	 * @return True if valid, false otherwise.
	 */
	private boolean isValidColor(String color) {
		if (color == null) return false;
		return color.startsWith("#") && color.length() == 7 || color.matches("&[0-9a-fA-F]");
	}

	/**
	 * Gets the hex color or color code associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The color string if available, null otherwise.
	 */
	public String getColor(String colorName) {
		EmoteColorConfig config = getEmoteColor(colorName);
		return (config != null) ? config.getColor() : null;
	}

	/**
	 * Gets the permission associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The permission string if available, null otherwise.
	 */
	public String getPermission(String colorName) {
		EmoteColorConfig config = getEmoteColor(colorName);
		return (config != null) ? config.getPermission() : null;
	}

	/**
	 * Gets the denied message associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The denied message string if available, null otherwise.
	 */
	public String getDeniedMessage(String colorName) {
		EmoteColorConfig config = getEmoteColor(colorName);
		return (config != null) ? config.getDeniedMessage() : null;
	}

	/**
	 * Checks if a color is defined in the configuration.
	 *
	 * @param colorName The name of the color.
	 * @return True if the color is defined, false otherwise.
	 */
	public boolean isColorDefined(String colorName) {
		return emoteColors.containsKey(colorName.toLowerCase());
	}

	/**
	 * Gets the EmoteColorConfig object associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The EmoteColorConfig object if available, null otherwise.
	 */
	public EmoteColorConfig getEmoteColor(String colorName) {
		return emoteColors.get(colorName.toLowerCase());
	}

	/**
	 * Gets all defined emote colors.
	 *
	 * @return A map of all emote colors defined in the configuration.
	 */
	public Map<String, EmoteColorConfig> getAllColors() {
		return emoteColors;
	}

	/**
	 * Gets the default emote color configuration.
	 *
	 * @return The default emote color configuration.
	 */
	public EmoteColorConfig getDefaultColor() {
		return emoteColors.get(DEFAULT_COLOR_NAME);
	}

	/**
	 * Inner class to represent the configuration of each emote color.
	 */
	public static class EmoteColorConfig {
		private final String color;
		private final String permission;
		private final String deniedMessage;

		public EmoteColorConfig(String color, String permission, String deniedMessage) {
			this.color = color;
			this.permission = permission;
			this.deniedMessage = deniedMessage;
		}

		public String getColor() {
			return color;
		}

		public String getPermission() {
			return permission;
		}

		public String getDeniedMessage() {
			return deniedMessage;
		}
	}
}
