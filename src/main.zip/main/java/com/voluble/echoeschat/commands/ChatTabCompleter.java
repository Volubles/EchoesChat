package com.voluble.echoeschat.commands;

import com.voluble.echoeschat.EchoesChat;
import com.voluble.echoeschat.managers.EmoteColorManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChatTabCompleter implements TabCompleter {

	private final EchoesChat plugin;
	private final EmoteColorManager emoteColorManager;

	public ChatTabCompleter(EchoesChat plugin, EmoteColorManager emoteColorManager) {
		this.plugin = plugin;
		this.emoteColorManager = emoteColorManager;
	}

	@Override
	public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
		List<String> suggestions = new ArrayList<>();

		if (args.length == 1) {
			// Suggest main commands based on permission
			if (sender.hasPermission("echoeschat.reload")) {
				if ("reload".startsWith(args[0].toLowerCase())) {
					suggestions.add("reload");
				}
			}
			if (sender.hasPermission("echoeschat.emotecolor")) {
				if ("emotecolor".startsWith(args[0].toLowerCase())) {
					suggestions.add("emotecolor");
				}
			}
		} else if (args.length == 2 && args[0].equalsIgnoreCase("emotecolor")) {
			// Suggest available emote colors from EmoteColorManager
			if (sender instanceof Player) {
				Player player = (Player) sender;
				for (Map.Entry<String, EmoteColorManager.EmoteColorConfig> entry : emoteColorManager.getEmoteColors().entrySet()) {
					String colorName = entry.getKey();
					EmoteColorManager.EmoteColorConfig config = entry.getValue();
					if (player.hasPermission(config.getPermission()) && colorName.startsWith(args[1].toLowerCase())) {
						suggestions.add(colorName);
					}
				}
			}
		}

		return suggestions;
	}
}
