package com.voluble.echoeschat.commands;

import com.voluble.echoeschat.EchoesChat;
import com.voluble.echoeschat.managers.EmoteColorManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.StringJoiner;

public class ChatCommand implements CommandExecutor {

	private final EchoesChat plugin;
	private final EmoteColorManager emoteColorManager;
	private final Map<String, EmoteColorManager.EmoteColorConfig> emoteColors;

	public ChatCommand(EchoesChat plugin, EmoteColorManager emoteColorManager) {
		this.plugin = plugin;
		this.emoteColorManager = emoteColorManager;
		this.emoteColors = emoteColorManager.getEmoteColors();
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if (!(sender instanceof Player)) {
			sender.sendMessage(ChatColor.RED + "This command can only be used by players.");
			return true;
		}

		Player player = (Player) sender;
		if (args.length == 0) {
			player.sendMessage(ChatColor.GOLD + "Usage: /chat reload | /chat emotecolor <color>");
			return true;
		}

		if (args[0].equalsIgnoreCase("reload")) {
			if (!player.hasPermission("echoeschat.admin")) {
				player.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
				return true;
			}
			plugin.reloadConfig();
			player.sendMessage(ChatColor.GREEN + "Configuration reloaded.");
			return true;
		}

		if (args[0].equalsIgnoreCase("emotecolor")) {
			if (args.length < 2) {
				player.sendMessage(ChatColor.GOLD + "Available colors: " + getAvailableColorsMessage());
				return true;
			}

			String colorName = args[1].toLowerCase();
			if (!emoteColors.containsKey(colorName)) {
				player.sendMessage(ChatColor.RED + "Invalid color name. Please choose from: " + getAvailableColorsMessage());
				return true;
			}

			EmoteColorManager.EmoteColorConfig colorConfig = emoteColors.get(colorName);
			if (!player.hasPermission(colorConfig.getPermission())) {
				player.sendMessage(ChatColor.translateAlternateColorCodes('&', colorConfig.getDeniedMessage()));
				return true;
			}

			plugin.getPlayerEmoteColors().put(player.getUniqueId(), colorName);
			plugin.savePlayerEmoteColors();
			player.sendMessage(ChatColor.GREEN + "Your emote color has been set to " + ChatColor.translateAlternateColorCodes('&', colorConfig.getColor()) + colorName);
			return true;
		}

		return false;
	}

	/**
	 * Gets a formatted message of all available emote colors.
	 *
	 * @return A formatted string listing all emote colors.
	 */
	private String getAvailableColorsMessage() {
		StringJoiner colorList = new StringJoiner(", ");
		for (Map.Entry<String, EmoteColorManager.EmoteColorConfig> entry : emoteColors.entrySet()) {
			String colorName = entry.getKey();
			String colorCode = entry.getValue().getColor();
			colorList.add(ChatColor.translateAlternateColorCodes('&', colorCode) + colorName + ChatColor.RESET);
		}
		return colorList.toString();
	}
}