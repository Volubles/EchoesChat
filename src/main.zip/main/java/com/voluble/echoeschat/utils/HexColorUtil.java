package com.voluble.echoeschat.utils;

import net.md_5.bungee.api.ChatColor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HexColorUtil {

	// This pattern matches both hex colors (e.g., &#FF5733) and & color codes (e.g., &a)
	private static final Pattern HEX_COLOR_PATTERN = Pattern.compile("(&#[A-Fa-f0-9]{6})|(&[0-9a-fA-F])");

	/**
	 * Applies hex colors and standard color codes to a message using Minecraft's ChatColor.
	 *
	 * @param message The input message with hex color codes (e.g., &#FF5733) or standard color codes (e.g., &a).
	 * @return The message with applied colors.
	 */
	public static String applyHexColors(String message) {
		Matcher matcher = HEX_COLOR_PATTERN.matcher(message);
		StringBuffer buffer = new StringBuffer();

		while (matcher.find()) {
			String hexCode = matcher.group();

			if (hexCode.startsWith("&#")) {
				// Handle hex color codes (e.g., &#FF5733)
				matcher.appendReplacement(buffer, ChatColor.of(hexCode.substring(1)).toString());
			} else if (hexCode.startsWith("&")) {
				// Handle standard Minecraft color codes (e.g., &a)
				matcher.appendReplacement(buffer, ChatColor.translateAlternateColorCodes('&', hexCode).toString());
			}
		}
		matcher.appendTail(buffer);

		return buffer.toString();
	}
}
