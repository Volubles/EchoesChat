package com.voluble.echoeschat.managers;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.Map;

public class EmoteColorManager {

	private final Map<String, EmoteColorConfig> emoteColors = new HashMap<>();

	public EmoteColorManager(FileConfiguration config) {
		loadEmoteColors(config);
	}

	/**
	 * Loads emote colors from the config file into memory.
	 *
	 * @param config The configuration file to load emote colors from.
	 */
	private void loadEmoteColors(FileConfiguration config) {
		if (config.contains("emoteColors")) {
			for (String key : config.getConfigurationSection("emoteColors").getKeys(false)) {
				String color = config.getString("emoteColors." + key + ".color");
				String permission = config.getString("emoteColors." + key + ".permission");
				String deniedMessage = config.getString("emoteColors." + key + ".deniedMessage");
				emoteColors.put(key.toLowerCase(), new EmoteColorConfig(color, permission, deniedMessage));
			}
		}
	}

	/**
	 * Gets the hex color or color code associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The color string if available, null otherwise.
	 */
	public String getColor(String colorName) {
		EmoteColorConfig config = emoteColors.get(colorName.toLowerCase());
		return (config != null) ? config.getColor() : null;
	}

	/**
	 * Gets the permission associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The permission string if available, null otherwise.
	 */
	public String getPermission(String colorName) {
		EmoteColorConfig config = emoteColors.get(colorName.toLowerCase());
		return (config != null) ? config.getPermission() : null;
	}

	/**
	 * Gets the denied message associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The denied message string if available, null otherwise.
	 */
	public String getDeniedMessage(String colorName) {
		EmoteColorConfig config = emoteColors.get(colorName.toLowerCase());
		return (config != null) ? config.getDeniedMessage() : null;
	}

	/**
	 * Checks if a color is defined in the configuration.
	 *
	 * @param colorName The name of the color.
	 * @return True if the color is defined, false otherwise.
	 */
	public boolean isColorDefined(String colorName) {
		return emoteColors.containsKey(colorName.toLowerCase());
	}

	/**
	 * Gets the EmoteColorConfig object associated with a color name.
	 *
	 * @param colorName The name of the color.
	 * @return The EmoteColorConfig object if available, null otherwise.
	 */
	public EmoteColorConfig getEmoteColor(String colorName) {
		return emoteColors.get(colorName.toLowerCase());
	}

	/**
	 * Gets all defined emote colors.
	 *
	 * @return A map of all emote colors defined in the configuration.
	 */
	public Map<String, EmoteColorConfig> getEmoteColors() {
		return emoteColors;
	}

	/**
	 * Inner class to represent the configuration of each emote color.
	 */
	public static class EmoteColorConfig {
		private final String color;
		private final String permission;
		private final String deniedMessage;

		public EmoteColorConfig(String color, String permission, String deniedMessage) {
			this.color = color;
			this.permission = permission;
			this.deniedMessage = deniedMessage;
		}

		public String getColor() {
			return color;
		}

		public String getPermission() {
			return permission;
		}

		public String getDeniedMessage() {
			return deniedMessage;
		}
	}
}
