package com.voluble.echoeschat.listeners;

import com.voluble.echoeschat.ChatChannel;
import com.voluble.echoeschat.manager.ChannelManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {
	private final ChannelManager channelManager;

	public PlayerJoinListener(ChannelManager channelManager) {
		this.channelManager = channelManager;
	}

	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
		ChatChannel defaultChannel = channelManager.getDefaultChannel();
		if (defaultChannel != null) {
			channelManager.setPlayerChannel(event.getPlayer(), defaultChannel);
		}
	}

}
