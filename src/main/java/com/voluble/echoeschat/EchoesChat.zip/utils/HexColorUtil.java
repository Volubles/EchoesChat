package com.voluble.echoeschat.utils;

import net.md_5.bungee.api.ChatColor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HexColorUtil {

	// This is some serious fucking code that i dont understand but lets fucking use it and see how far we get. thank you fucking github
	private static final Pattern HEX_COLOR_PATTERN = Pattern.compile("&#[A-Fa-f0-9]{6}");

	/**
	 * Applies hex colors to a message using Minecraft's ChatColor.
	 *
	 * @param message The input message with hex color codes (e.g., &#FF5733).
	 * @return The message with applied hex colors.
	 */
	public static String applyHexColors(String message) {
		Matcher matcher = HEX_COLOR_PATTERN.matcher(message);
		StringBuffer buffer = new StringBuffer();

		while (matcher.find()) {
			// Extract the hex code (e.g., &#FF5733)
			String hexCode = matcher.group().substring(1); // Remove the '&' prefix
			matcher.appendReplacement(buffer, ChatColor.of(hexCode).toString());
		}
		matcher.appendTail(buffer);

		return buffer.toString();
	}
}

