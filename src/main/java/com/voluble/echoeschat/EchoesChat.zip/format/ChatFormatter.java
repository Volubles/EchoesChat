package com.voluble.echoeschat.format;

import com.voluble.echoeschat.ChatChannel;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.entity.Player;

public class ChatFormatter {

	public String formatMessage(Player player, String message, ChatChannel channel) {
		// Automatically wrap the message in quotes if none exist
		if (!message.contains("\"")) {
			message = "\"" + message.trim() + "\"";
		}

		StringBuilder formattedMessage = new StringBuilder();
		boolean insideQuotes = false;
		int currentIndex = 0;

		while (currentIndex < message.length()) {
			int nextQuoteIndex = message.indexOf("\"", currentIndex);

			if (nextQuoteIndex == -1) {
				// Treat the remaining part as an emote
				String emotePart = message.substring(currentIndex).trim();
				if (!emotePart.isEmpty()) {
					formattedMessage.append(formatEmote(player, emotePart));
				}
				break;
			}

			if (insideQuotes) {
				// Process quoted dialogue
				String dialoguePart = message.substring(currentIndex, nextQuoteIndex).trim();
				if (!dialoguePart.isEmpty()) {
					formattedMessage.append(ChatColor.WHITE).append("\"").append(dialoguePart).append("\" ");
				}
			} else {
				// Process emote or action outside of quotes
				String emotePart = message.substring(currentIndex, nextQuoteIndex).trim();
				if (!emotePart.isEmpty()) {
					formattedMessage.append(formatEmote(player, emotePart)).append(" ");
				}
			}

			insideQuotes = !insideQuotes;
			currentIndex = nextQuoteIndex + 1;
		}

		return channel.getFormat()
				.replace("{prefix}", channel.getPrefix().isEmpty() ? "" : channel.getPrefix() + " ")
				.replace("{player}", player.getDisplayName())
				.replace("{message}", formattedMessage.toString().trim());
	}

	private String formatEmote(Player player, String emote) {
		if (emote.isEmpty()) {
			return "";
		}
		return getEmoteColor(player) + emote + ChatColor.RESET; // Ensure colors are reset after emote
	}

	private String getEmoteColor(Player player) {
		if (player.hasPermission("rpchat.emote.gold")) {
			return ChatColor.GOLD.toString();
		} else if (player.hasPermission("rpchat.emote.red")) {
			return ChatColor.RED.toString();
		} else {
			return ChatColor.GRAY.toString(); // Default color
		}
	}
}
