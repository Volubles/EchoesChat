package com.voluble.echoeschat;

import com.voluble.echoeschat.commands.ChannelCommand;
import com.voluble.echoeschat.commands.ChatCommand;
import com.voluble.echoeschat.commands.ChatTabCompleter;
import com.voluble.echoeschat.format.ChatFormatter;
import com.voluble.echoeschat.listeners.ChatEventListener;
import com.voluble.echoeschat.manager.ChannelManager;
import com.voluble.echoeschat.utils.CommandRegistrar;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collections;
import java.util.List;

public final class EchoesChat extends JavaPlugin {

	private ChannelManager channelManager;
	private ChatFormatter chatFormatter;

	@Override
	public void onEnable() {
		getLogger().info("EchoesChat has been enabled!");

		// Load configurations
		loadConfigurations();

		// Initialize managers and utilities
		initializeComponents();

		// Register commands and event listeners
		registerCommands();
		registerListeners();
	}

	@Override
	public void onDisable() {
		getLogger().info("EchoesChat has been disabled!");
	}

	private void loadConfigurations() {
		saveDefaultConfig();
		saveResource("channels.yml", false);
	}

	private void initializeComponents() {
		channelManager = new ChannelManager(this);
		chatFormatter = new ChatFormatter();
		getLogger().info("Loaded channels: " + channelManager.getAllChannels().keySet());
	}

	private void registerCommands() {
		// Register dynamic channel commands
		for (ChatChannel channel : channelManager.getAllChannels().values()) {
			if (channel.isEnabled()) {
				for (String command : channel.getCommands()) {
					String commandName = command.replace("/", "");
					BukkitCommand dynamicCommand = createDynamicChannelCommand(channel, commandName);

					// Register the command dynamically
					CommandRegistrar.registerCommand(commandName, "echoeschat", dynamicCommand);
				}
			}
		}

		// Register the /chat command
		registerChatCommand();
	}

	private void registerChatCommand() {
		BukkitCommand chatCommand = new BukkitCommand("chat") {
			@Override
			public boolean execute(org.bukkit.command.CommandSender sender, String label, String[] args) {
				return new ChatCommand(EchoesChat.this).onCommand(sender, this, label, args);
			}

			@Override
			public List<String> tabComplete(org.bukkit.command.CommandSender sender, String alias, String[] args) {
				if (!(sender instanceof Player)) {
					return Collections.emptyList();
				}
				return new ChatTabCompleter(EchoesChat.this).onTabComplete(sender, this, alias, args);
			}
		};

		chatCommand.setDescription("Primary command for EchoesChat.");
		chatCommand.setAliases(Collections.singletonList("ec")); // Optional alias
		CommandRegistrar.registerCommand("chat", "echoeschat", chatCommand);
	}

	private BukkitCommand createDynamicChannelCommand(ChatChannel channel, String commandName) {
		return new BukkitCommand(commandName) {
			@Override
			public boolean execute(CommandSender sender, String label, String[] args) {
				return new ChannelCommand(channel, channelManager, chatFormatter)
						.onCommand(sender, this, label, args);
			}

			@Override
			public List<String> tabComplete(CommandSender sender, String alias, String[] args) {
				// Ensure tab completion is restricted to players with permission
				if (!(sender instanceof Player)) {
					return Collections.emptyList();
				}
				Player player = (Player) sender;
				if (!player.hasPermission(channel.getPermission())) {
					return Collections.emptyList(); // Hide from unauthorized players
				}
				return Collections.singletonList(commandName); // Return only the command name
			}
		};
	}



	private void registerListeners() {
		getServer().getPluginManager().registerEvents(new ChatEventListener(channelManager, chatFormatter), this);
	}

	public ChannelManager getChannelManager() {
		return channelManager;
	}

	public ChatFormatter getChatFormatter() {
		return chatFormatter;
	}
}
