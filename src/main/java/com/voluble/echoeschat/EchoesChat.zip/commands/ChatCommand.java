package com.voluble.echoeschat.commands;

import com.voluble.echoeschat.EchoesChat;
import com.voluble.echoeschat.utils.HexColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ChatCommand implements CommandExecutor {

	private final EchoesChat plugin;

	public ChatCommand(EchoesChat plugin) {
		this.plugin = plugin;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if (args.length == 0) {
			sender.sendMessage(HexColorUtil.applyHexColors("&#A02334EchoesChat Plugin v" + plugin.getDescription().getVersion()));
			sender.sendMessage(HexColorUtil.applyHexColors("&#A02334Usage: /chat reload"));
			return true;
		}

		if (args[0].equalsIgnoreCase("reload")) {
			// Check if the sender has the required permission
			if (!sender.hasPermission("echoeschat.admin")) {
				sender.sendMessage(HexColorUtil.applyHexColors("&#A02334You don't have permission to perform this command."));
				return true;
			}

			plugin.reloadConfig(); // Reload the main config.yml
			plugin.getChannelManager().reloadChannels(); // Reload the channels.yml
			sender.sendMessage(HexColorUtil.applyHexColors("&#8FD14FEchoesChat configuration and channels have been reloaded."));
			return true;
		}

		sender.sendMessage(HexColorUtil.applyHexColors("&#A02334Invalid command. Use /chat reload."));
		return true;
	}
}