package com.voluble.echoeschat.commands;

import com.voluble.echoeschat.EchoesChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

public class ChatTabCompleter implements TabCompleter {

	public ChatTabCompleter(EchoesChat echoesChat) {
	}

	@Override
	public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
		List<String> suggestions = new ArrayList<>();

		if (args.length == 1) {
			// Add command suggestions based on permission
			if (sender.hasPermission("echoeschat.reload")) {
				if ("reload".startsWith(args[0].toLowerCase())) {
					suggestions.add("reload");
				}
			}
		}

		return suggestions;
	}
}
