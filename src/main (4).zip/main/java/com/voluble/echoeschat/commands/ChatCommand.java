package com.voluble.echoeschat.commands;

import com.voluble.echoeschat.ChatChannel;
import com.voluble.echoeschat.EchoesChat;
import com.voluble.echoeschat.managers.ChannelManager;
import com.voluble.echoeschat.managers.EmoteColorManager;
import com.voluble.echoeschat.managers.EmoteColorManager.EmoteColorConfig;
import com.voluble.echoeschat.utils.HexColorUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ChatCommand implements CommandExecutor {
	private final EchoesChat plugin;
	private final EmoteColorManager emoteColorManager;
	private final Map<UUID, String> playerEmoteColors;
	private final ChannelManager channelManager;


	/**
	 * Constructor for the ChatCommand class.
	 *
	 * @param plugin            The main plugin instance.
	 * @param emoteColorManager The EmoteColorManager to handle emote color configurations.
	 * @param playerEmoteColors A map storing player-specific emote colors by their UUID.
	 */
	public ChatCommand(EchoesChat plugin, EmoteColorManager emoteColorManager, Map<UUID, String> playerEmoteColors, ChannelManager channelManager) {
		this.plugin = plugin;
		this.emoteColorManager = emoteColorManager;
		this.playerEmoteColors = playerEmoteColors;
		this.channelManager = channelManager;
	}

	/**
	 * Executes the /chat command.
	 *
	 * @param sender  The command sender (e.g., player or console).
	 * @param command The command being executed.
	 * @param label   The alias used for the command.
	 * @param args    The command arguments.
	 * @return True if the command was successfully executed, false otherwise.
	 */
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		// Ensure the sender is a player
		if (!(sender instanceof Player)) {
			sender.sendMessage(ChatColor.RED + "Only players can use this command.");
			return false;
		}

		Player player = (Player) sender;

		if (args.length > 0 && args[0].equalsIgnoreCase("emotecolor")) {
			if (args.length == 1) {
				// Display the available emote colors
				player.sendMessage(getAvailableColorsMessage(player));
				return true;
			}

			// Handle color change logic for /chat emotecolor <color>
			String colorName = args[1].toLowerCase();
			EmoteColorConfig colorConfig = emoteColorManager.getEmoteColor(colorName);

			if (colorConfig == null) {
				player.sendMessage(ChatColor.RED + "Invalid emote color. Use /chat emotecolor to see available options.");
				return false;
			}

			if (!player.hasPermission(colorConfig.getPermission())) {
				player.sendMessage(ChatColor.RED + colorConfig.getDeniedMessage());
				return false;
			}

			playerEmoteColors.put(player.getUniqueId(), colorName);
			player.sendMessage(HexColorUtil.applyHexColors("&7Your emote color has been set to "
					+ HexColorUtil.applyHexColors(colorConfig.getColor())
					+ colorName + ChatColor.RESET + "!"));
			return true;
		}

		// Single argument
		if (args.length == 1) {
			if (args[0].equalsIgnoreCase("reload")) {
				// Handle /chat reload
				if (!player.hasPermission("echoeschat.reload")) {
					player.sendMessage(ChatColor.RED + "You do not have permission to reload the plugin.");
					return false;
				}

				// Reload plugin configurations and data
				plugin.reloadConfig();
				plugin.getChannelManager().reloadChannels(plugin.getConfig());
				plugin.getEmoteColorManager().reloadColors(plugin.getConfig());
				plugin.loadDataConfig();
				plugin.loadPlayerEmoteColors();
				player.sendMessage(ChatColor.GREEN + "EchoesChat has been reloaded!");
				return true;
			} else {
				// Handle emote color change
				String colorName = args[0].toLowerCase();
				EmoteColorConfig colorConfig = emoteColorManager.getEmoteColor(colorName);

				// Check if the color exists
				if (colorConfig == null) {
					player.sendMessage(ChatColor.RED + "Invalid emote color. Use /chat to see available options.");
					return false;
				}

				// Check if the player has permission for the selected color
				if (!player.hasPermission(colorConfig.getPermission())) {
					player.sendMessage(ChatColor.RED + colorConfig.getDeniedMessage());
					return false;
				}
			}
		}
		if (args.length > 0) {
			// Handle mutechannel command
			if (args[0].equalsIgnoreCase("mutechannel")) {
				if (args.length < 2) {
					player.sendMessage(ChatColor.RED + "Usage: /chat mutechannel <channel_name>");
					return true;
				}
				String channelName = args[1].toLowerCase();
				handleMuteChannel(player, channelName);
				return true;
			}

			// Handle unmutechannel command
			if (args[0].equalsIgnoreCase("unmutechannel")) {
				if (args.length < 2) {
					player.sendMessage(ChatColor.RED + "Usage: /chat unmutechannel <channel_name>");
					return true;
				}
				String channelName = args[1].toLowerCase();
				handleUnmuteChannel(player, channelName);
				return true;
			}
			return true;
		}



		// Invalid usage
		player.sendMessage(ChatColor.RED + "Usage: /chat [emotecolor|reload]");
		return false;
	}

	/**
	 * Builds a message listing all available emote colors for the player.
	 *
	 * @param player The player requesting the list of available emote colors.
	 * @return A formatted string of available emote colors.
	 */
	private String getAvailableColorsMessage(Player player) {
		StringBuilder message = new StringBuilder(ChatColor.GRAY + "Available Emote Colors: " + ChatColor.RESET);

		for (Map.Entry<String, EmoteColorConfig> entry : emoteColorManager.getAllColors().entrySet()) {
			String colorName = entry.getKey();
			EmoteColorConfig colorConfig = entry.getValue();
			String colorCode = colorConfig.getColor();

			// Skip if color name or code is null
			if (colorCode == null || colorName == null) continue;

			// Add color to the message if the player has permission
			if (player.hasPermission(colorConfig.getPermission())) {
				message.append(HexColorUtil.applyHexColors(colorCode))
						.append(colorName)
						.append(ChatColor.RESET)
						.append(", ");
			}
		}

		// Remove the trailing comma and space
		if (message.length() > 2) {
			message.setLength(message.length() - 2);
		}

		return message.toString();
	}
	/**
	 * Handles muting a chat channel for a player.
	 *
	 * @param player      The player muting the channel.
	 * @param channelName The name of the channel to mute.
	 */
	public void handleMuteChannel(Player player, String channelName) {
		ChatChannel channel = channelManager.getAllChannels().get(channelName.toLowerCase());
		if (channel == null) {
			player.sendMessage(ChatColor.RED + "Channel '" + channelName + "' does not exist.");
			return;
		}

		if (!player.hasPermission(channel.getPermission())) {
			player.sendMessage(ChatColor.RED + "You do not have permission to mute this channel.");
			return;
		}

		if (player.hasMetadata("muted_channels")) {
			List<String> mutedChannels = (List<String>) player.getMetadata("muted_channels").get(0).value();
			if (mutedChannels.contains(channelName.toLowerCase())) {
				player.sendMessage(ChatColor.RED + "Channel '" + channelName + "' is already muted.");
				return;
			}
			mutedChannels.add(channelName.toLowerCase());
			player.setMetadata("muted_channels", new FixedMetadataValue(plugin, mutedChannels));
		} else {
			List<String> mutedChannels = new ArrayList<>();
			mutedChannels.add(channelName.toLowerCase());
			player.setMetadata("muted_channels", new FixedMetadataValue(plugin, mutedChannels));
		}

		player.sendMessage(ChatColor.GREEN + "You have muted the channel: " + channelName);
	}

	/**
	 * Handles unmuting a chat channel for a player.
	 *
	 * @param player      The player unmuting the channel.
	 * @param channelName The name of the channel to unmute.
	 */
	public void handleUnmuteChannel(Player player, String channelName) {
		ChatChannel channel = channelManager.getAllChannels().get(channelName.toLowerCase());
		if (channel == null) {
			player.sendMessage(ChatColor.RED + "Channel '" + channelName + "' does not exist.");
			return;
		}

		if (player.hasMetadata("muted_channels")) {
			List<String> mutedChannels = (List<String>) player.getMetadata("muted_channels").get(0).value();
			if (mutedChannels.contains(channelName.toLowerCase())) {
				mutedChannels.remove(channelName.toLowerCase());
				player.setMetadata("muted_channels", new FixedMetadataValue(plugin, mutedChannels));
				player.sendMessage(ChatColor.GREEN + "You have unmuted the channel: " + channelName);
				return;
			}
		}

		player.sendMessage(ChatColor.RED + "Channel '" + channelName + "' is not muted.");
	}
}
